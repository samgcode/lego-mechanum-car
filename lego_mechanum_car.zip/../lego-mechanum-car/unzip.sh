cd ..
unzip lego_mechanum_car.zip
cd lego-mechanum-car